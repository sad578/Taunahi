# ❤️‍🔥Taunahi v3❤️‍🔥
### *💀Tired of tedious and dull farming on skyblock?💀*
### *❤️‍🩹I will help you.❤️‍🩹*
### *🖥Presenting Taunahi v3 the best collection of scripts such as:🖥*
## 🌾Farming scripts🌾
![2024-03-29_14 10 40](https://github.com/SpareContributor/Taunahi_v3/assets/165363101/f1ce8f70-a516-4fdd-987f-83b83bd7340c)
## ⚔️Combat scripts⚔️
![2024-03-29_14 11 07](https://github.com/SpareContributor/Taunahi_v3/assets/165363101/0ac44da4-5b77-4d49-8cb5-7abf76245120)
## 🪓Foraging scripts🪓
![2024-03-29_14 11 12](https://github.com/SpareContributor/Taunahi_v3/assets/165363101/867577a8-c296-4b6d-b9b6-562ea4d8ad92)
## 🎣Fishing scripts🎣
![2024-03-29_14 11 26](https://github.com/SpareContributor/Taunahi_v3/assets/165363101/24df5ebe-232d-429b-89bb-f61487f8acc3)
# 💖And many other scripts for Hypixel Skyblock💖
